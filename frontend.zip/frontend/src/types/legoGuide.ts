export const BRICK_TYPES = [
  "1x1",
  "1x2",
  "1x3",
  "1x4",
  "1x5",
  "2x2",
  "2x3",
  "2x4",
  "2x5",
] as const;

export type BrickType = (typeof BRICK_TYPES)[number];

// 브릭 식별자 타입 (나중에 문자열 포맷을 바꿔도, 타입 이름은 그대로 쓸 수 있게 분리)
export type BrickId = string;

// STEP1 결과를 서버에 저장해두고 STEP2에서 조회하기 위한 식별자
export type AnalysisId = string;

// 레고 브릭 한 개에 대한 기본 정보
export interface Brick {
  id: BrickId; // 고유 식별자
  x: number; // 가로 좌표
  y: number; // 세로 좌표
  z: number; // 높이 (1차 버전은 항상 0, 추후 2.5D/3D 확장용)
  color: string; // 색상
  type: BrickType; // 브릭 종류
}

// 조립 가이드에 대한 메타데이터
export interface GuideMeta {
  title?: string; // 디자인 제목
  width?: number; // 모자이크 가로 크기 (그리드 단위)
  height?: number; // 모자이크 세로 크기 (그리드 단위)
  language?: "ko" | "en"; // 설명 언어
}

// AI 서버로 보내는 조립 가이드 생성 요청 (기존 방식 유지)
export interface GuideRequest {
  bricks: Brick[]; // 모자이크에 사용되는 모든 브릭
  meta?: GuideMeta; // 부가 정보
}

// 이미지 분석 옵션(체크박스/옵션 UI가 만드는 값)
export interface AnalyzeOptions {
  gridSize: "16x16" | "32x32" | "48x48";
  colorLimit: 0 | 8 | 16 | 24;
  brickTypes: BrickType[];
  brickMode?: "auto" | "manual";
}

// 타일링 결과 배치 단위
export interface Placement {
  id?: BrickId;
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  type: BrickType;
}

/**
 * STEP2 (analysisId 기반 조립 단계 생성) 요청/응답
 * - 서버: POST /api/guide/steps
 */
export interface BuildStepsRequest {
  analysisId: AnalysisId;
}

/**
 * SSOT(단일 기준) 구조를 위한 섹션
 * - sections[] 가 화면의 "챕터/묶음" 역할
 * - steps[] 는 실제 단계를 SSOT로 보관하고, section.stepIds로 참조
 */
export interface GuideSection {
  id: string;
  title?: string;
  stepIds: string[]; // GuideStepSSOT.id를 참조
  order?: number;
}

/**
 * 조립 과정의 한 단계 정보 (기존 V1)
 */
export interface GuideStepV1 {
  step: number; // 단계 번호
  title: string; // 단계 제목
  description: string; // 단계 설명 문장
  brickIds: BrickId[]; // 이 단계에서 사용할 브릭들의 id 목록
}

/**
 * 조립 과정의 한 단계 정보 (V2: placements 기반)
 */
export interface GuideStepV2 {
  index: number; // 단계 번호
  title: string;
  description?: string;
  placements: Placement[];
}

/**
 * 조립 과정의 한 단계 정보 (V3: SSOT 기반)
 * - sections/steps 구조를 쓰는 경우, step을 숫자로 고정하지 않고 id 기반으로 참조
 */
export interface GuideStepSSOT {
  id: string;
  title: string;
  description?: string;

  // 단계에서 추가/적용할 배치 (있으면 렌더링/가이드에 활용)
  placements?: Placement[];

  // (선택) 기존 V1을 같이 지원하려는 경우
  brickIds?: BrickId[];

  order?: number;
}

// 서버가 V1/V2/V3 중 무엇을 내려줘도 수용
export type GuideStep = GuideStepV1 | GuideStepV2 | GuideStepSSOT;

// 가이드 전체에 대한 간단 통계 정보 (기존)
export interface GuideStats {
  totalBricks: number;
  totalSteps: number;
}

// 부품 수량
// 서버가 BrickType 키를 주로 쓰겠지만, 유연하게 문자열 키도 허용
export type PartsMap = Partial<Record<BrickType, number>> & Record<string, number>;

/**
 * 팔레트(색상별 수량)
 * - 프로젝트에서 자주 쓰는 값이라 타입으로 고정해두면 UI/검증이 쉬움
 */
export interface PaletteItem {
  hex: string; // 예: "#ffcc00"
  count: number;
  name?: string; // 선택(예: "Bright Yellow")
}

/**
 * STEP2 응답(analysisId로 조회한 조립 단계 결과)
 * - 서버 구현에 따라 bricks를 내려줄 수도/안 내려줄 수도 있어 optional
 */
export interface BuildStepsResponse {
  analysisId?: AnalysisId;
  sections: GuideSection[];
  steps: GuideStep[];
  bricks?: Brick[];
}

/**
 * AI 서버에서 돌아오는 최종 조립 가이드 응답
 * - STEP1: analyze 결과 + analysisId 발급 (meta/placements/parts/palette 등)
 * - STEP2: sections/steps 생성 (on-demand)
 */
export interface GuideResponse {
  // STEP1
  analysisId?: AnalysisId | null;

  summary?: string; // 전체 요약 문장
  stats?: GuideStats; // 통계 정보
  meta?: GuideMeta;

  brick_types?: BrickType[]; // 서버 정규화 결과
  placements?: Placement[]; // 전체 배치
  parts?: PartsMap; // 타입별 수량
  palette?: PaletteItem[]; // 색상 팔레트(선택)

  // STEP2 (SSOT)
  sections?: GuideSection[];
  steps?: GuideStep[];

  // STEP2에서 bricks를 내려주는 경우 수용(서버 정책에 따라 선택)
  bricks?: Brick[];
}

/**
 * ---------- Type Guards ----------
 * 화면/컴포넌트에서 GuideStep 타입 분기할 때 사용
 */
export function isGuideStepV1(step: GuideStep): step is GuideStepV1 {
  return typeof (step as GuideStepV1).step === "number";
}

export function isGuideStepV2(step: GuideStep): step is GuideStepV2 {
  return typeof (step as GuideStepV2).index === "number";
}

export function isGuideStepSSOT(step: GuideStep): step is GuideStepSSOT {
  return typeof (step as GuideStepSSOT).id === "string";
}
