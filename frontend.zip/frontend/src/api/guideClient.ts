// frontend/src/api/guideClient.ts
import type {
  GuideResponse,
  AnalyzeOptions,
  BuildStepsRequest,
  BuildStepsResponse,
} from "../types/legoGuide";
import { BRICK_TYPES } from "../types/legoGuide";

type NormalizedApiErrorKind =
  | "TIMEOUT"
  | "NETWORK"
  | "HTTP_4XX"
  | "HTTP_5XX"
  | "INVALID_RESPONSE"
  | "ABORTED";

export type NormalizedApiError = {
  kind: NormalizedApiErrorKind;
  message: string;
  status?: number;
};

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:9000";

function timeoutSignal(ms: number) {
  const controller = new AbortController();
  const id = window.setTimeout(() => controller.abort(), ms);
  return { signal: controller.signal, clear: () => window.clearTimeout(id) };
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null;
}

function toErrorMessage(v: unknown, fallback: string) {
  if (typeof v === "string" && v.trim()) return v;
  if (isRecord(v) && typeof v.message === "string" && v.message.trim()) return v.message;
  try {
    if (v != null) return JSON.stringify(v);
  } catch {
    // ignore
  }
  return fallback;
}

function toNumberOrNull(v: unknown): number | null {
  if (typeof v === "number") return Number.isFinite(v) ? v : null;
  if (typeof v === "string") {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

function normalizeAnalyzeOptions(options?: unknown): AnalyzeOptions | undefined {
  if (!options || typeof options !== "object") return undefined;
  const o = options as any;

  const gridSize =
    typeof o.gridSize === "string" ? o.gridSize : undefined;

  const colorLimit = toNumberOrNull(o.colorLimit) ?? undefined;

  const brickTypes = Array.isArray(o.brickTypes)
    ? o.brickTypes.filter((t: any) => BRICK_TYPES.includes(t))
    : undefined;

  const brickMode =
    o.brickMode === "auto" || o.brickMode === "manual" ? o.brickMode : undefined;

  return {
    ...(gridSize ? { gridSize } : {}),
    ...(colorLimit !== undefined ? { colorLimit } : {}),
    ...(brickTypes ? { brickTypes } : {}),
    ...(brickMode ? { brickMode } : {}),
  };
}

async function requestJson<T>(
  url: string,
  init: RequestInit,
  timeoutMs: number,
  signal?: AbortSignal
): Promise<T> {
  const { signal: timeoutSig, clear } = timeoutSignal(timeoutMs);

  const mergedSignal = (() => {
    if (!signal) return timeoutSig;
    const controller = new AbortController();
    const onAbort = () => controller.abort();
    signal.addEventListener("abort", onAbort, { once: true });
    timeoutSig.addEventListener("abort", onAbort, { once: true });
    return controller.signal;
  })();

  try {
    const res = await fetch(url, { ...init, signal: mergedSignal });

    const contentType = res.headers.get("content-type") ?? "";
    const isJson = contentType.includes("application/json");

    if (!res.ok) {
      let message = `HTTP ${res.status}`;

      if (isJson) {
        try {
          const data: any = await res.json();
          const raw = data?.detail ?? data?.message ?? data?.error;
          message = toErrorMessage(raw, message);
        } catch {
          // ignore
        }
      } else {
        try {
          const text = await res.text();
          if (text) message = text;
        } catch {
          // ignore
        }
      }

      const kind =
        res.status >= 500 ? "HTTP_5XX" : "HTTP_4XX";

      const err: NormalizedApiError = {
        kind,
        message,
        status: res.status,
      };
      throw err;
    }

    if (!isJson) {
      const err: NormalizedApiError = {
        kind: "INVALID_RESPONSE",
        message: "서버 응답이 JSON이 아닙니다.",
        status: res.status,
      };
      throw err;
    }

    return (await res.json()) as T;
  } catch (e: any) {
    if (e?.name === "AbortError") {
      const err: NormalizedApiError = { kind: "ABORTED", message: "aborted" };
      throw err;
    }
    if (e && typeof e === "object" && typeof e.kind === "string") throw e;

    const msg = String(e?.message ?? "");
    if (msg.includes("Failed to fetch") || msg.includes("NetworkError")) {
      const err: NormalizedApiError = { kind: "NETWORK", message: msg };
      throw err;
    }

    const err: NormalizedApiError = { kind: "INVALID_RESPONSE", message: msg || "unknown" };
    throw err;
  } finally {
    clear();
  }
}

export async function analyzeGuide(
  imageFile: File,
  options?: unknown,
  signal?: AbortSignal
): Promise<GuideResponse> {
  const form = new FormData();
  form.append("image", imageFile);

  const normalized = normalizeAnalyzeOptions(options);
  if (normalized) form.append("options", JSON.stringify(normalized));

  return requestJson<GuideResponse>(
    `${API_BASE_URL}/api/guide/analyze`,
    { method: "POST", body: form },
    30000,
    signal
  );
}

/*
  STEP2: analysisId 기반으로 조립 단계를 생성한다.

  왜 별도 API인가?
  - STEP1: 이미지 분석/팔레트/기초 가이드 데이터
  - STEP2: (옵션/전략에 따라) 섹션 분할 + 브릭 패킹 + 단계 생성은 비용이 더 큼
  - 그래서 on-demand로 호출하고, 결과는 analysisId로 조회/생성하는 구조가 유지보수에 유리
*/
export async function buildGuideSteps(
  req: BuildStepsRequest,
  signal?: AbortSignal
): Promise<BuildStepsResponse> {
  return requestJson<BuildStepsResponse>(
    `${API_BASE_URL}/api/guide/steps`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req),
    },
    60000,
    signal
  );
}
